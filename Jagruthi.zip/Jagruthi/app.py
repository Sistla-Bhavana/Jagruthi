from flask import Flask, render_template
import json

app = Flask(__name__)

# Schemes with detailed bilingual descriptions
schemes = {
    "Ayushman Bharat": {
        "title_telugu": "ఆయుష్మాన్ భారత్",
        "desc": """Ayushman Bharat provides insurance coverage up to ₹5 lakh per family/year.
Eligibility: BPL families and vulnerable groups.
Benefits: Hospitalization, surgeries, diagnostic tests, medicines, post-treatment support.
How to avail: Register at nearest PHC or via Ayushman Bharat portal.
Documents: Aadhar, BPL/SECC, family ID.
Cashless treatment at empanelled hospitals.
Scheme covers pre-existing conditions and maternal health.
Special benefits for women and children.
Community awareness sessions conducted regularly.
Follow-up and rehabilitation support provided.
Focus on rural and remote areas.
Aim: Reduce out-of-pocket health expenses.
Encourages institutional deliveries.
Ensures health equity for marginalized families.
National Health Authority oversees the scheme.
Helpline: 14555""",
        "desc_telugu": """ఆయుష్మాన్ భారత్ ప్రతి కుటుంబానికి సంవత్సరానికి ₹5 లక్షల వరకు భీమా కవర్.
అర్హత: పేద కుటుంబాలు మరియు అసహ్య గ్రూపులు.
లాభాలు: ఆసుపత్రి, సర్జరీలు, టెస్టులు, మందులు, పోస్ట్-ట్రీట్మెంట్ సపోర్ట్.
ఎలా పొందాలి: దగ్గరి PHC లో నమోదు లేదా పోర్టల్ ద్వారా.
డాక్యుమెంట్లు: ఆధార్, BPL/SECC, కుటుంబ ID.
ఎంపనల్ ఆసుపత్రులలో క్యాష్‌లెస్ ట్రీట్మెంట్.
పూర్వ-స్థితి పరిస్థితులు మరియు మాతృ ఆరోగ్యం కవర్.
మహిళలు మరియు పిల్లల కోసం ప్రత్యేక లాభాలు.
సముదాయ అవగాహన సెషన్లు క్రమం తప్పకుండా.
ఫాలో-అప్ మరియు రీహాబిలిటేషన్ సపోర్ట్.
గ్రామీణ మరియు దూర ప్రాంతాలపై దృష్టి.
ప్రధాన లక్ష్యం: ఆరోగ్య వ్యయాన్ని తగ్గించడం.
ఇన్‌స్టిట్యూషనల్ డెలివరీలు.
ప్రధానంగా హితం లభించని కుటుంబాల కోసం సమానత్వం.
నేషనల్ హెల్త్ అథారిటీ పర్యవేక్షిస్తుంది.
హెల్ప్‌లైన్: 14555"""
    },
    "National Health Mission": {
        "title_telugu": "నేషనల్ హెల్త్ మిషన్",
        "desc": """NHM improves healthcare in rural & urban areas.
Programs: maternal & child health, immunization, disease control, health system strengthening.
Eligibility: All citizens, priority to rural areas.
Services: Free immunization, antenatal & postnatal care.
PHCs & community health centers provide grassroots services.
Special initiatives for women, children, elderly, disabled.
Awareness campaigns conducted in villages and towns.
Collaboration with state governments & NGOs.
Financial assistance for maternal deliveries.
Home visits for monitoring.
Telemedicine in remote areas.
Aim: Reduce maternal & infant mortality.
Registration: Local health center or online.
Promotes preventive care & nutrition.
Empowers communities to maintain health records.
Monitoring via HMIS system.
Promotes sanitation & hygiene.""",
        "desc_telugu": """NHM గ్రామీణ మరియు పట్టణ ప్రాంతాలలో ఆరోగ్య సేవలను మెరుగుపరుస్తుంది.
కార్యక్రమాలు: మాతృ & శిశు ఆరోగ్యం, టీకా, వ్యాధుల నియంత్రణ, ఆరోగ్య వ్యవస్థ బలీకరణ.
అర్హత: అన్ని పౌరులు, ప్రాధాన్యం గ్రామీణ ప్రాంతాలకు.
సేవలు: ఉచిత టీకా, ante-natal & post-natal కేర్.
PHCలు మరియు కమ్యూనిటీ హెల్త్ సెంటర్స్基层 సేవలు అందిస్తాయి.
మహిళలు, పిల్లలు, వృద్ధులు, వైకల్యాలు ఉన్నవారికి ప్రత్యేక కార్యక్రమాలు.
గ్రామాలు మరియు పట్టణాలలో అవగాహన శిబిరాలు.
రాష్ట్ర ప్రభుత్వాలు & NGOలతో సహకారం.
మాతృ డెలివరీలకు ఆర్థిక సహాయం.
హోమ్ విసిట్ల ద్వారా పర్యవేక్షణ.
దూర ప్రాంతాలలో టెలిమెడిసిన్.
లక్ష్యం: మాతృ & శిశు మరణాలను తగ్గించడం.
నమోదు: స్థానిక ఆరోగ్య కేంద్రం లేదా ఆన్‌లైన్.
ప్రివెంటివ్ కేర్ & పోషణ కార్యక్రమాలు.
సమాజాలను ఆరోగ్య రికార్డుల నిర్వహణకు శక్తివంతం చేస్తుంది.
HMIS ద్వారా పర్యవేక్షణ.
శౌచాలయం & శుభ్రత ప్రోత్సహిస్తుంది."""
    },
    "Pradhan Mantri Surakshit Matritva Abhiyan": {
        "title_telugu": "ప్రధాన మంత్రి సురక్షిత మాతృత్వా అభియాన్",
        "desc": """Free antenatal checkups for pregnant women.
Eligibility: All pregnant women in 2nd & 3rd trimester.
Benefits: Health checkups, diagnostic tests, counseling.
How to avail: Visit nearest PHC/CHC on 9th of every month.
Documentation: Pregnant woman's ID, ANC card.
Monitoring by government health staff.
Promotes institutional delivery.
Health awareness sessions provided.
Focus on high-risk pregnancies.
Ensures maternal & child health.
Guidance on nutrition & immunization.
Cash incentives for institutional delivery.
Collaboration with ASHA workers.
Regular follow-ups conducted.
Provides referral for complications.""",
        "desc_telugu": """గర్భిణీ మహిళల కోసం ఉచిత ante-natal తనిఖీలు.
అర్హత: రెండవ & మూడవ త్రైమాస్టర్ లో ఉన్న మహిళలు.
లాభాలు: ఆరోగ్య తనిఖీలు, పరీక్షలు, కౌన్సెలింగ్.
ఎలా పొందాలి: ప్రతి నెల 9 తేదీన దగ్గరి PHC/CHC కి వెళ్ళండి.
డాక్యుమెంట్లు: గర్భిణీ మహిళ ID, ANC కార్డు.
ఆధార ప్రభుత్వ ఆరోగ్య ఉద్యోగుల ద్వారా పర్యవేక్షణ.
ఇన్‌స్టిట్యూషనల్ డెలివరీ ప్రోత్సహించడం.
ఆరోగ్య అవగాహన సెషన్లు.
ఎత్తుకుపోయే గర్భిణీ మహిళలపై దృష్టి.
మాతృ & శిశు ఆరోగ్యం నిర్ధారిస్తుంది.
పోషణ & టీకా పై మార్గదర్శనం.
ఇన్‌స్టిట్యూషనల్ డెలివరీకి నగదు ప్రోత్సాహాలు.
ASHA ఉద్యోగులతో సహకారం.
నియమిత ఫాలో-అప్.
సమస్యల కోసం రిఫerral అందిస్తుంది."""
    },
    "Janani Suraksha Yojana": {
        "title_telugu": "జనని సురక్షా యోజన",
        "desc": """Provides cash incentives for institutional deliveries.
Eligibility: Pregnant women delivering in government hospitals.
Benefits: Transportation support, cash for mother & newborn.
How to avail: Register at local PHC.
Documentation: Pregnant woman's ID, hospital record.
Monitored by health staff.
Promotes safe deliveries.
Regular awareness campaigns.
Focus on reducing maternal & infant mortality.
Includes postnatal care guidance.
Coordination with ASHA workers.
Financial support for marginalized families.
Encourages institutional health practices.
Supports nutrition & immunization.
Home visits by health workers.
Aim: Reduce out-of-pocket delivery expenses.""",
        "desc_telugu": """ఇన్‌స్టిట్యూషనల్ డెలివరీలకు నగదు ప్రోత్సాహాలు.
అర్హత: ప్రభుత్వ ఆసుపత్రిలో డెలివరీ ఇచ్చే గర్భిణీ మహిళలు.
లాభాలు: రవాణా సపోర్ట్, తల్లీ & శిశువు కోసం నగదు.
ఎలా పొందాలి: స్థానిక PHC లో నమోదు.
డాక్యుమెంట్లు: గర్భిణీ మహిళ ID, ఆసుపత్రి రికార్డు.
ఆరోగ్య సిబ్బంది ద్వారా పర్యవేక్షణ.
సురక్షిత డెలివరీలను ప్రోత్సహిస్తుంది.
నియమిత అవగాహన శిబిరాలు.
మాతృ & శిశు మరణాలను తగ్గించడంపై దృష్టి.
పోస్ట్ నాటల్ కేర్ మార్గదర్శనం.
ASHA ఉద్యోగులతో సమన్వయం.
విత్తనాత్మక కుటుంబాలకు ఆర్థిక సహాయం.
ఇన్‌స్టిట్యూషనల్ ఆరోగ్య నిబంధనలను ప్రోత్సహిస్తుంది.
పోషణ & టీకా మద్దతు.
ఆరోగ్య ఉద్యోగుల హోమ్ విసిట్లు.
లక్ష్యం: డెలివరీ ఖర్చులను తగ్గించడం."""
    },
    "National Digital Health Mission": {
        "title_telugu": "నేషనల్ డిజిటల్ హెల్త్ మిషన్",
        "desc": """Aims to create digital health IDs for citizens.
Eligibility: All citizens.
Benefits: Digital health records, easier doctor consultations.
How to avail: Register online at NDHM portal.
Documentation: Aadhar card.
Integration with hospitals & clinics.
Promotes telemedicine & e-health services.
Secure cloud-based storage.
Enables health data tracking over time.
Supports health analytics for policy making.
Increases efficiency of health system.
Awareness campaigns conducted regularly.
Focus on rural & remote areas.
Guides vaccination & preventive care.
Collaboration with state & central agencies.
Empowers citizens to access their health data.""",
        "desc_telugu": """ప్రజలకు డిజిటల్ హెల్త్ ID సృష్టించడం లక్ష్యం.
అర్హత: అన్ని పౌరులు.
లాభాలు: డిజిటల్ హెల్త్ రికార్డులు, డాక్టర్ కన్సల్టేషన్ సులభం.
ఎలా పొందాలి: NDHM పోర్టల్ లో ఆన్‌లైన్ నమోదు.
డాక్యుమెంట్లు: ఆధార్.
ఆసుపత్రులు & క్లినిక్స్ తో ఇంటిగ్రేషన్.
టెలిమెడిసిన్ & e-హెల్త్ సేవలను ప్రోత్సహిస్తుంది.
సురక్షిత క్లౌడ్ స్టోరేజ్.
ఆరోగ్య డేటా ట్రాకింగ్.
పాలసీ మేకింగ్ కోసం హెల్త్ అనలిటిక్స్.
ఆరోగ్య వ్యవస్థ సామర్థ్యాన్ని పెంచుతుంది.
అవగాహన శిబిరాలు.
గ్రామీణ & దూర ప్రాంతాలపై దృష్టి.
టీకా & ప్రివెంటివ్ కేర్ మార్గదర్శనం.
రాష్ట్ర & కేంద్ర ఏజెన్సీలతో సహకారం.
ప్రజలు తమ ఆరోగ్య డేటా యాక్సెస్ చేయగలరు."""
    }
}

# PHCs / Anganwadi centers
phcs_namburu = [
    {"name": "PHC Namburu", "lat": 16.247, "lng": 80.440, "address": "Main Road, Namburu", "contact": "08645-123456"},
    {"name": "PHC Guntur West", "lat": 16.253, "lng": 80.445, "address": "Guntur West, Namburu", "contact": "08645-654321"},
    {"name": "Anganwadi Center 1", "lat": 16.248, "lng": 80.442, "address": "Village Center, Namburu", "contact": "N/A"},
    {"name": "Anganwadi Center 2", "lat": 16.249, "lng": 80.447, "address": "Community Hall, Namburu", "contact": "N/A"}
]

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/schemes')
def scheme_list():
    return render_template('schemes.html', schemes=schemes)

@app.route('/phc')
def phc_list():
    centers_json = json.dumps(phcs_namburu)
    return render_template('phc.html', centers_json=centers_json)

@app.route('/health')
def health():
    return render_template('health_form.html')

if __name__ == '__main__':
    app.run(debug=True)