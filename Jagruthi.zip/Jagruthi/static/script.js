let isTelugu = false;
document.getElementById("toggle-lang").addEventListener("click", () => {
    isTelugu = !isTelugu;
    document.querySelectorAll(".telugu").forEach(el => {
        el.style.display = isTelugu ? "block" : "none";
    });
});

let darkMode = false;
document.getElementById("toggle-mode").addEventListener("click", () => {
    darkMode = !darkMode;
    document.body.classList.toggle("dark-mode", darkMode);
});

function showScheme(name){
    const schemes = {
        "Ayushman Bharat": {desc:"Health insurance scheme for vulnerable families. Covers hospitalization costs and provides cashless treatment.", telugu:"అత్యంత పేద కుటుంబాల కోసం ఆరోగ్య భీమా పథకం. ఆసుపత్రి ఖర్చులు మరియు క్యాష్‌లెస్ చికిత్స అందిస్తుంది."},
        "National Health Mission": {desc:"Aims to improve access to quality health services in rural areas.", telugu:"గ్రామీణ ప్రాంతాల్లో నాణ్యమైన ఆరోగ్య సేవల ప్రాప్తిని మెరుగుపరచడానికి లక్ష్యం."},
        "Janani Suraksha Yojana": {desc:"Promotes institutional deliveries and maternal care for pregnant women.", telugu:"గర్భిణీ మహిళలకు ఆసుపత్రి ప deliveries మరియు మాతృ కేర్ ను ప్రోత్సహిస్తుంది."}
    };
    document.getElementById("scheme-title").innerText = name;
    document.getElementById("scheme-desc").innerText = schemes[name].desc;
    document.getElementById("scheme-telugu").innerText = schemes[name].telugu;
    document.getElementById("scheme-popup").style.display = "block";
}
function closePopup(){ document.getElementById("scheme-popup").style.display = "none"; }